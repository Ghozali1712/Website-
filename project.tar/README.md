# Indomaret Stock Checker

Aplikasi untuk memeriksa stok produk di toko Indomaret dan memberikan notifikasi melalui Telegram Bot.

## Fitur Utama

- Login dengan akun Indomaret (KlikIndomaret)
- Menambahkan dan mengelola toko Indomaret
- Memeriksa stok produk berdasarkan kode PLU
- Notifikasi via Telegram Bot
- Menampilkan riwayat pemeriksaan stok

## Cara Menjalankan Aplikasi

### Prasyarat

- [Node.js](https://nodejs.org/) versi 16 atau lebih tinggi
- NPM (sudah termasuk dalam instalasi Node.js)

### Langkah Instalasi dan Penggunaan

1. **Unduh dan Ekstrak File**
   - Unduh kode sumber aplikasi dari repositori atau file ZIP yang disediakan
   - Ekstrak ke folder pilihan Anda

2. **Instalasi Dependensi**
   - Buka terminal/command prompt
   - Navigasi ke folder tempat Anda mengekstrak aplikasi
   - Jalankan perintah untuk menginstal dependensi:
   ```bash
   npm install
   ```

3. **Jalankan Aplikasi**
   - Setelah instalasi selesai, jalankan aplikasi:
   ```bash
   npm run dev
   ```
   - Aplikasi akan berjalan di port 5000 secara default
   - Server akan menampilkan pesan "serving on port 5000" jika berhasil

4. **Akses Aplikasi**
   - Buka browser web Anda
   - Kunjungi alamat: `http://localhost:5000`
   - Anda akan melihat halaman login aplikasi

### Struktur Folder

```
indomaret-stock-checker/
├── client/             # Kode frontend (React)
├── server/             # Kode backend (Express)
├── shared/             # Skema data bersama
├── package.json        # Konfigurasi dependensi
├── tsconfig.json       # Konfigurasi TypeScript
└── README.md           # Dokumentasi
```

### Konfigurasi Telegram Bot (Opsional)

Untuk menggunakan fitur notifikasi Telegram Bot:

1. Buat bot Telegram baru melalui [BotFather](https://t.me/botfather)
2. Dapatkan token bot dari BotFather
3. Buat file `.env` di root folder dengan isi:
   ```
   BOT_TOKEN=token_bot_anda_disini
   ```
4. Restart aplikasi untuk menerapkan perubahan

## Cara Penggunaan

### Login
- Masuk dengan akun KlikIndomaret Anda
- Gunakan nomor telepon dan password yang terdaftar di Indomaret
- Sesi login akan bertahan hingga 30 menit dan akan diperpanjang secara otomatis saat Anda menggunakan aplikasi

### Mengelola Toko
- Tambahkan kode toko Indomaret yang ingin dipantau
- Kode toko biasanya berupa kombinasi huruf dan angka (contoh: TCBS, TRF9)
- Anda dapat menambahkan beberapa toko sekaligus dengan memisahkannya dengan koma
- Klik ikon hapus untuk menghapus toko dari daftar

### Memeriksa Stok
- Masukkan kode PLU produk yang ingin diperiksa
- Anda dapat memasukkan beberapa PLU sekaligus
- Pilih toko yang ingin diperiksa stoknya
- Hasil pemeriksaan akan menampilkan nama produk, harga, dan jumlah stok

### Notifikasi Telegram
- Tambahkan bot ke grup atau chat pribadi
- Gunakan perintah `/start` untuk memulai
- Ikuti petunjuk untuk mengatur toko dan produk yang ingin dipantau

## Troubleshooting

### Masalah Umum dan Solusi

- **Error saat login**: 
  - Pastikan nomor telepon dan password sudah benar
  - Periksa koneksi internet Anda
  - Coba hapus cache browser dan coba lagi

- **Aplikasi tidak berjalan**: 
  - Pastikan Node.js terinstal dengan benar
  - Periksa apakah port 5000 sudah digunakan aplikasi lain
  - Periksa log error di terminal

- **Gagal menambah toko**: 
  - Pastikan format kode toko sudah benar
  - Periksa apakah toko tersebut sudah ada di daftar

- **Bot Telegram tidak merespon**: 
  - Pastikan token bot sudah benar di file .env
  - Pastikan bot sudah distart dengan perintah /start
  - Periksa log error di terminal server

## Pengembangan Lanjutan

- Server menggunakan Express.js dengan TypeScript
- Frontend menggunakan React dengan TypeScript dan TailwindCSS
- State management menggunakan React Context API dan TanStack Query
- Database menggunakan penyimpanan dalam memori (dapat diubah ke database persisten)

## Lisensi

MIT