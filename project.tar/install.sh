#!/bin/bash
# Script untuk instalasi aplikasi Indomaret Stock Checker

echo "===== Indomaret Stock Checker - Instalasi ====="
echo "Memulai proses instalasi..."

# Cek apakah Node.js terinstall
if ! command -v node &> /dev/null; then
    echo "Node.js tidak ditemukan. Silakan install Node.js terlebih dahulu."
    echo "Anda dapat mengunduhnya di: https://nodejs.org/"
    exit 1
fi

# Cek versi Node.js
NODE_VERSION=$(node -v | cut -d'v' -f2)
NODE_MAJOR=$(echo $NODE_VERSION | cut -d'.' -f1)

if [ $NODE_MAJOR -lt 16 ]; then
    echo "Versi Node.js yang terdeteksi: $NODE_VERSION"
    echo "Aplikasi ini membutuhkan Node.js versi 16 atau lebih tinggi."
    echo "Silakan perbarui Node.js Anda dan coba lagi."
    exit 1
fi

echo "Versi Node.js yang terdeteksi: $NODE_VERSION (OK)"

# Menginstal dependensi
echo "Menginstal dependensi aplikasi..."
npm install

if [ $? -ne 0 ]; then
    echo "Gagal menginstal dependensi. Silakan coba lagi atau periksa koneksi internet Anda."
    exit 1
fi

echo "Dependensi berhasil diinstal!"
echo "===== Instalasi Selesai ====="
echo ""
echo "Untuk menjalankan aplikasi, gunakan perintah:"
echo "npm run dev"
echo ""
echo "Setelah aplikasi berjalan, buka browser dan akses: http://localhost:5000"