import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import { initTelegramBot } from "./services/telegramBot";
import { 
  login, 
  refreshToken, 
  getUserProfile, 
  checkStockByPlu 
} from "./services/indomaretApi";

// Initialize a memory store for sessions
import createMemoryStore from 'memorystore';
const MemoryStore = createMemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up session middleware
  app.use(session({
    cookie: { 
      maxAge: 86400000, // 24 hours
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax"
    },
    store: new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    resave: false,
    saveUninitialized: false,
    secret: process.env.SESSION_SECRET || 'indomaret-stock-checker-secret'
  }));

  // Auth routes
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { phoneNumber, password } = req.body;
      
      if (!phoneNumber || !password) {
        return res.status(400).json({ message: 'Phone number and password are required' });
      }
      
      const { accessToken, refreshToken: refreshTokenValue, expiresIn } = await login(phoneNumber, password);
      const userProfile = await getUserProfile(accessToken);
      
      // Calculate expiry time
      const expiresAt = new Date();
      expiresAt.setSeconds(expiresAt.getSeconds() + expiresIn);
      
      // Store in session
      req.session.accessToken = accessToken;
      req.session.refreshToken = refreshTokenValue;
      req.session.expiresAt = expiresAt;
      req.session.userProfile = userProfile;
      
      res.json({
        userProfile,
        tokenInfo: {
          accessToken,
          refreshToken: refreshTokenValue,
          expiresAt
        }
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Login failed';
      res.status(401).json({ message: errorMessage });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: 'Failed to logout' });
      }
      res.json({ message: 'Logged out successfully' });
    });
  });

  app.post('/api/auth/refresh-token', async (req, res) => {
    try {
      // Check if user is logged in via session
      if (!req.session.accessToken || !req.session.refreshToken) {
        console.error("Refresh token attempt without valid session");
        return res.status(401).json({ message: 'No valid session found' });
      }
      
      console.log("Attempting to refresh token from session");
      
      // Instead of trying to refresh the token with the Indomaret API
      // which seems to be causing 500 errors, we'll just extend the
      // current session duration in our application
      
      // Simply extend the current token's expiry time by 30 minutes
      const expiresAt = new Date();
      expiresAt.setMinutes(expiresAt.getMinutes() + 30);
      
      // Keep the same tokens but update expiry
      req.session.expiresAt = expiresAt;
      
      // Save the session explicitly
      req.session.save(err => {
        if (err) {
          console.error("Error saving session after extending token:", err);
          return res.status(500).json({ message: 'Failed to save session' });
        }
        
        console.log("Session extended successfully, new expiry:", expiresAt);
        
        // Return the same tokens with new expiry
        res.json({
          tokenInfo: {
            accessToken: req.session.accessToken,
            refreshToken: req.session.refreshToken,
            expiresAt
          }
        });
      });
    } catch (error) {
      console.error("Unexpected error in token extension:", error);
      
      // Clear session on error
      req.session.destroy(err => {
        if (err) {
          console.error("Error destroying session after token extension failure:", err);
        }
        
        res.status(401).json({ 
          message: error instanceof Error 
            ? error.message 
            : 'Session extension failed' 
        });
      });
    }
  });

  app.get('/api/auth/profile', async (req, res) => {
    try {
      if (!req.session.accessToken) {
        return res.status(401).json({ message: 'Not authenticated' });
      }
      
      // Check if token is about to expire
      const expiresAt = req.session.expiresAt ? new Date(req.session.expiresAt) : null;
      const now = new Date();
      const fiveMinutesInMs = 5 * 60 * 1000;
      
      if (expiresAt && expiresAt.getTime() - now.getTime() < fiveMinutesInMs) {
        // Instead of refreshing, extend the session expiry
        const newExpiresAt = new Date();
        newExpiresAt.setMinutes(newExpiresAt.getMinutes() + 30);
        req.session.expiresAt = newExpiresAt;
        
        console.log("Session extended during profile fetch, new expiry:", newExpiresAt);
      }
      
      // Use profile from session if available, otherwise fetch it
      let userProfile = req.session.userProfile;
      
      if (!userProfile) {
        try {
          userProfile = await getUserProfile(req.session.accessToken);
          req.session.userProfile = userProfile;
        } catch (profileError) {
          console.error("Failed to fetch profile:", profileError);
          // If we can't get the profile, but we have a session,
          // create a basic profile from the session data
          userProfile = {
            name: "Indomaret User",
            phoneNumber: "Unknown"
          };
        }
      }
      
      res.json(userProfile);
    } catch (error) {
      console.error("Error in profile endpoint:", error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to get profile';
      res.status(500).json({ message: errorMessage });
    }
  });

  app.get('/api/auth/session', (req, res) => {
    if (!req.session.accessToken || !req.session.userProfile) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    res.json({
      userProfile: req.session.userProfile,
      tokenInfo: {
        accessToken: req.session.accessToken,
        refreshToken: req.session.refreshToken,
        expiresAt: req.session.expiresAt
      }
    });
  });

  // Store routes
  app.get('/api/stores', (req, res) => {
    if (!req.session.accessToken) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    // Get stores from session or initialize empty array
    const stores = req.session.stores || [];
    res.json(stores);
  });

  app.post('/api/stores', (req, res) => {
    if (!req.session.accessToken) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    const { storeCode } = req.body;
    
    if (!storeCode) {
      return res.status(400).json({ message: 'Store code is required' });
    }
    
    // Handle multiple store codes separated by commas
    const storeCodes = storeCode.split(',').map(code => code.trim()).filter(Boolean);
    
    // Get existing stores or initialize empty array
    const existingStores = req.session.stores || [];
    const newStores = [];
    
    for (const code of storeCodes) {
      // Check if store already exists
      if (!existingStores.some(store => store.storeCode === code)) {
        const newStore = { storeCode: code };
        existingStores.push(newStore);
        newStores.push(newStore);
      }
    }
    
    // Save stores to session
    req.session.stores = existingStores;
    
    if (newStores.length === 0) {
      return res.status(400).json({ message: 'Store already exists' });
    }
    
    // Return the first new store if only one was added, otherwise return all new stores
    res.status(201).json(newStores.length === 1 ? newStores[0] : newStores);
  });

  app.delete('/api/stores/:storeCode', (req, res) => {
    if (!req.session.accessToken) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    const { storeCode } = req.params;
    
    // Get existing stores or initialize empty array
    const existingStores = req.session.stores || [];
    
    // Filter out the store to delete
    const updatedStores = existingStores.filter(store => store.storeCode !== storeCode);
    
    if (existingStores.length === updatedStores.length) {
      return res.status(404).json({ message: 'Store not found' });
    }
    
    // Save updated stores to session
    req.session.stores = updatedStores;
    
    res.json({ message: 'Store deleted successfully' });
  });

  // Stock check routes
  app.post('/api/stock/check', async (req, res) => {
    try {
      if (!req.session.accessToken) {
        return res.status(401).json({ message: 'Not authenticated' });
      }
      
      const { pluList, storeCodes } = req.body;
      
      if (!pluList || !Array.isArray(pluList) || pluList.length === 0) {
        return res.status(400).json({ message: 'PLU list is required' });
      }
      
      if (!storeCodes || !Array.isArray(storeCodes) || storeCodes.length === 0) {
        return res.status(400).json({ message: 'Store codes are required' });
      }
      
      // Extend session expiry during stock checks
      const newExpiresAt = new Date();
      newExpiresAt.setMinutes(newExpiresAt.getMinutes() + 30);
      req.session.expiresAt = newExpiresAt;
      
      console.log("Session extended during stock check, new expiry:", newExpiresAt);
      
      // Check stock for each store and PLU
      const results = [];
      
      for (const storeCode of storeCodes) {
        try {
          // First reset the cart for this store
          const products = [];
          
          for (const plu of pluList) {
            try {
              const product = await checkStockByPlu(
                req.session.accessToken,
                storeCode,
                plu
              );
              products.push(product);
            } catch (productError) {
              console.error(`Error checking stock for PLU ${plu} at store ${storeCode}:`, productError);
              // Add product with error info
              products.push({
                plu,
                productName: 'Unknown Product',
                stock: 0,
                price: 'N/A',
                error: productError instanceof Error ? productError.message : 'Unknown error'
              });
            }
          }
          
          results.push({
            store: { storeCode },
            products
          });
        } catch (storeError) {
          console.error(`Error with store ${storeCode}:`, storeError);
          // Add store with error info
          results.push({
            store: { storeCode },
            products: [],
            error: storeError instanceof Error ? storeError.message : 'Unknown error'
          });
        }
      }
      
      // Save the last check time
      req.session.lastCheckTime = new Date();
      
      res.json(results);
    } catch (error) {
      console.error("Global error in stock check:", error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to check stock';
      res.status(500).json({ message: errorMessage });
    }
  });

  app.get('/api/stock/recent', (req, res) => {
    // This would normally get recent checks from a database
    // For simplicity, we'll just return a success message
    res.json([]);
  });

  // Initialize Telegram bot
  initTelegramBot();

  const httpServer = createServer(app);
  return httpServer;
}
