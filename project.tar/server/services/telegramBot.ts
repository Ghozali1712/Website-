import TelegramBot, { Message } from 'node-telegram-bot-api';
import fs from 'fs/promises';
import { 
  login, 
  refreshToken, 
  getUserProfile,
  checkStockByPlu
} from './indomaretApi';

// Data structure to store user data
interface UserData {
  storeCodes: Record<number, string[]>;
  userTokens: Record<number, string>;
  userRefreshTokens: Record<number, string>;
  tokenExpiryTimes: Record<number, number>;
}

// Initialize with empty data
let userData: UserData = {
  storeCodes: {},
  userTokens: {},
  userRefreshTokens: {},
  tokenExpiryTimes: {}
};

// Get the token from environment variable or use the provided one
const token = process.env.TELEGRAM_BOT_TOKEN || '7808073414:AAGZ96kFZK4NEkMZH8_E6e2cXm5-X4T4fqE';

/**
 * Initialize the Telegram bot
 */
export async function initTelegramBot() {
  // Load data from file
  await loadData();

  // Create bot instance
  const bot = new TelegramBot(token, { polling: true });

  // Define keyboard menu
  const menuKeyboard = {
    reply_markup: {
      keyboard: [
        ['/login', '/setstore'],
        ['/check', '/help']
      ],
      resize_keyboard: true,
      one_time_keyboard: true
    }
  };

  // Handle /start command
  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, 'Halo! Silakan pilih menu di bawah:', menuKeyboard);
  });

  // Handle /help command
  bot.onText(/\/help/, (msg) => {
    const chatId = msg.chat.id;
    const helpText = `
Berikut adalah daftar perintah yang tersedia:
/login - Login ke sistem
/setstore - Setel kode toko
/check - Cek stok produk
/help - Menampilkan bantuan
    `;
    bot.sendMessage(chatId, helpText, menuKeyboard);
  });

  // Handle /login command
  bot.onText(/\/login/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, 'Masukkan nomor HP:');
    bot.once('message', (msg) => {
      const phoneNumber = msg.text;

      bot.sendMessage(chatId, 'Masukkan password:');
      bot.once('message', async (msg) => {
        const password = msg.text;

        try {
          if (phoneNumber && password) {
            await loginUser(phoneNumber, password, chatId);
            bot.sendMessage(chatId, 'Login berhasil dan token disimpan.', menuKeyboard);
          } else {
            throw new Error('Nomor HP atau password tidak valid');
          }
        } catch (error) {
          bot.sendMessage(chatId, `Login gagal: ${error instanceof Error ? error.message : 'Unknown error'}`, menuKeyboard);
        }
      });
    });
  });

  // Handle /setstore command
  bot.onText(/\/setstore/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, 'Masukkan StoreCode (pisahkan dengan koma, contoh: 12345,67890,11223):');
    bot.once('message', (msg) => {
      if (!msg.text) {
        return bot.sendMessage(chatId, 'Store code tidak valid', menuKeyboard);
      }
      
      const storeCodesInput = msg.text.trim().split(',').map(code => code.trim());
      userData.storeCodes[chatId] = storeCodesInput;
      saveData();
      bot.sendMessage(chatId, `StoreCode ${storeCodesInput.join(', ')} berhasil disimpan.`, menuKeyboard);
    });
  });

  // Handle /check command
  bot.onText(/\/check/, async (msg) => {
    const chatId = msg.chat.id;

    if (!userData.storeCodes[chatId] || userData.storeCodes[chatId].length === 0) {
      return bot.sendMessage(chatId, 'Anda belum menyimpan StoreCode. Gunakan /setstore untuk menyimpan StoreCode.', menuKeyboard);
    }

    if (!userData.userTokens[chatId]) {
      return bot.sendMessage(chatId, 'Anda belum login. Gunakan /login untuk login.', menuKeyboard);
    }

    try {
      // Check and refresh token if needed
      const token = await checkAndRefreshToken(chatId);

      bot.sendMessage(chatId, 'Masukkan daftar PLU (pisahkan dengan koma, contoh: 12345,67890,11223):');
      bot.once('message', async (msg) => {
        if (!msg.text) {
          return bot.sendMessage(chatId, 'PLU tidak valid', menuKeyboard);
        }
        
        const pluList = msg.text.trim().split(',').map(plu => plu.trim());

        try {
          // Get user profile
          const userProfile = await getUserProfile(token);

          let resultText = `Hai ${userProfile.name} | ${userProfile.phoneNumber}\n============================\n`;

          for (const storeCode of userData.storeCodes[chatId]) {
            resultText += `Toko: ${storeCode}\n`;

            try {
              for (const plu of pluList) {
                try {
                  const product = await checkStockByPlu(token, storeCode, plu);
                  resultText += `
Produk: ${product.productName}
PLU: ${product.plu}
Stok: ${product.stock}
Harga: ${product.price}
${product.discountValue ? `Diskon: ${product.discountValue} - ${product.discountText}` : ''}
----------------------------\n`;
                } catch (pluError) {
                  resultText += `PLU ${plu} gagal diproses: ${pluError instanceof Error ? pluError.message : 'Unknown error'}\n----------------------------\n`;
                }
              }
            } catch (error) {
              resultText += `Terjadi kesalahan pada toko ${storeCode}: ${error instanceof Error ? error.message : 'Unknown error'}\n----------------------------\n`;
            }
          }

          await bot.sendMessage(chatId, resultText, menuKeyboard);
        } catch (error) {
          bot.sendMessage(chatId, `Terjadi kesalahan: ${error instanceof Error ? error.message : 'Unknown error'}`, menuKeyboard);
        }
      });
    } catch (error) {
      bot.sendMessage(chatId, `Gagal memperbarui token: ${error instanceof Error ? error.message : 'Unknown error'}`, menuKeyboard);
    }
  });

  console.log('Telegram bot initialized and running!');
}

/**
 * Load user data from file
 */
async function loadData() {
  try {
    const data = await fs.readFile('data.json', 'utf8');
    const parsedData = JSON.parse(data);
    userData.storeCodes = parsedData.storeCodes || {};
    userData.userTokens = parsedData.userTokens || {};
    userData.userRefreshTokens = parsedData.userRefreshTokens || {};
    userData.tokenExpiryTimes = parsedData.tokenExpiryTimes || {};
  } catch (error) {
    console.log('Tidak ada data yang ditemukan, membuat file baru...');
  }
}

/**
 * Save user data to file
 */
async function saveData() {
  const data = JSON.stringify(userData);
  await fs.writeFile('data.json', data, 'utf8');
}

/**
 * Login user and store tokens
 */
async function loginUser(phoneNumber: string, password: string, chatId: number) {
  const { accessToken, refreshToken: refreshTokenValue, expiresIn } = await login(phoneNumber, password);
  
  userData.userTokens[chatId] = accessToken;
  userData.userRefreshTokens[chatId] = refreshTokenValue;
  userData.tokenExpiryTimes[chatId] = Date.now() + (expiresIn * 1000);
  
  await saveData();
  
  return accessToken;
}

/**
 * Check and refresh token if needed
 */
async function checkAndRefreshToken(chatId: number) {
  if (userData.tokenExpiryTimes[chatId] && userData.tokenExpiryTimes[chatId] < Date.now()) {
    // Token expired, refresh it
    const { accessToken, refreshToken: refreshTokenValue, expiresIn } = await refreshToken(userData.userRefreshTokens[chatId]);
    
    userData.userTokens[chatId] = accessToken;
    userData.userRefreshTokens[chatId] = refreshTokenValue;
    userData.tokenExpiryTimes[chatId] = Date.now() + (expiresIn * 1000);
    
    await saveData();
    
    return accessToken;
  }
  
  return userData.userTokens[chatId];
}
