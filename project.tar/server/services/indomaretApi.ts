import axios from 'axios';
import { IndomaretUserProfile, IndomaretProductStock } from '@shared/schema';

// Constants
const DEVICE_ID = 'e20b1b21-f08a-4ee6-b864-7bc14402d1fc';
const FCM_ID = 'e20b1b21-f08a-4ee6-b864-7bc14402d1fc';

// API URLs
const API_BASE_URL = 'https://ap-mc.klikindomaret.com';
const LOGIN_URL = `${API_BASE_URL}/assets-klikidmauth/api/post/customer/api/webapp/authentication/login`;
const REFRESH_TOKEN_URL = `${API_BASE_URL}/assets-klikidmauth/api/post/customer/api/webapp/authentication/refresh`;
const PROFILE_URL = `${API_BASE_URL}/assets-klikidmprofile/api/get/customer/api/webapp/profile`;
const ADD_TO_CART_URL = `${API_BASE_URL}/assets-klikidmgroceries/api/post/cart-xpress/api/webapp/cart/add-to-cart`;
const UPDATE_CART_URL = `${API_BASE_URL}/assets-klikidmorder/api/post/cart-xpress/api/webapp/cart/update-cart`;

/**
 * Login to Indomaret API
 */
export async function login(phoneNumber: string, password: string) {
  try {
    const body = {
      email: null,
      phoneNumber: phoneNumber.trim(),
      deviceId: DEVICE_ID,
      fcmId: FCM_ID,
      password: password.trim(),
    };

    const headers = {
      'User-Agent': 'Mozilla/5.0',
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json',
    };

    const response = await axios.post(LOGIN_URL, body, { headers });

    if (response.data.status === '00' && response.data.data.accessToken) {
      return {
        accessToken: `Bearer ${response.data.data.accessToken}`,
        refreshToken: response.data.data.refreshToken,
        expiresIn: response.data.data.expiresIn
      };
    } else {
      throw new Error(response.data.message || 'Login failed');
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(error.response?.data?.message || 'Login failed: Network error');
    }
    throw error;
  }
}

/**
 * Refresh token
 */
export async function refreshToken(refreshTokenValue: string) {
  try {
    console.log("Attempting to refresh token with: ", refreshTokenValue ? "Token exists" : "No token");
    
    // Validation check
    if (!refreshTokenValue || refreshTokenValue.trim() === '') {
      throw new Error('Invalid refresh token provided');
    }
    
    const body = {
      refreshToken: refreshTokenValue.trim(),
    };

    const headers = {
      'User-Agent': 'Mozilla/5.0',
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json',
    };

    const response = await axios.post(REFRESH_TOKEN_URL, body, { headers });
    console.log("Refresh token response status:", response.data.status);

    if (response.data.status === '00' && response.data.data && response.data.data.accessToken) {
      return {
        accessToken: `Bearer ${response.data.data.accessToken}`,
        refreshToken: response.data.data.refreshToken,
        expiresIn: response.data.data.expiresIn || 3600 // Default to 1 hour if not provided
      };
    } else {
      console.error("API returned unexpected response:", response.data);
      throw new Error(response.data.message || 'Failed to refresh token: Invalid response structure');
    }
  } catch (error) {
    console.error("Token refresh failed with error:", error);
    if (axios.isAxiosError(error)) {
      const responseData = error.response?.data;
      const errorMsg = responseData?.message || responseData?.error || 'Token refresh failed: Network error';
      throw new Error(errorMsg);
    }
    throw error;
  }
}

/**
 * Get user profile
 */
export async function getUserProfile(accessToken: string): Promise<IndomaretUserProfile> {
  try {
    const headers = {
      'User-Agent': 'Mozilla/5.0',
      'Accept': 'application/json, text/plain, */*',
      'Authorization': accessToken,
    };

    const response = await axios.get(PROFILE_URL, { headers });

    if (response.data.status === '00' && response.data.data) {
      return {
        name: response.data.data.name || 'User',
        phoneNumber: response.data.data.phoneNumber || 'Unknown'
      };
    } else {
      throw new Error(response.data.message || 'Failed to get profile');
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(error.response?.data?.message || 'Profile retrieval failed: Network error');
    }
    throw error;
  }
}

/**
 * Create body for resetting cart
 */
function createResetCartBody(storeCode: string) {
  return {
    storeCode: storeCode.trim(),
    latitude: 1,
    longitude: 1,
    mode: "PICKUP",
    districtId: "1",
    products: [],
  };
}

/**
 * Create body for adding product to cart
 */
function createAddToCartBody(storeCode: string, plu: string) {
  return {
    storeCode: storeCode.trim(),
    latitude: 1,
    longitude: 1,
    mode: "PICKUP",
    districtId: "1",
    permalink: "product-permalink",
    products: [
      {
        plu: plu.trim(),
        qty: 1,
      },
    ],
  };
}

/**
 * Reset cart for a store
 */
async function resetCart(accessToken: string, storeCode: string) {
  try {
    const body = createResetCartBody(storeCode);
    const headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0',
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.5',
      'Accept-Encoding': 'gzip, deflate, br, zstd',
      'Referer': 'https://www.klikindomaret.com/',
      'Content-Type': 'application/json',
      'Origin': 'https://www.klikindomaret.com',
      'Connection': 'keep-alive',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'no-cors',
      'Sec-Fetch-Site': 'same-site',
      'TE': 'trailers',
      'apps': '{"app_version":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0","device_class":"browser|browser","device_family":"none","device_id":"c03b3603-075e-4276-b420-a92d9ee93035","os_name":"Windows","os_version":"10"}',
      'Priority': 'u=4',
      'Pragma': 'no-cache',
      'Authorization': accessToken.trim(),
      'Cache-Control': 'no-cache',
    };

    const response = await axios.post(UPDATE_CART_URL, body, { headers });
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(error.response?.data?.message || `Failed to reset cart for store ${storeCode}: Network error`);
    }
    throw error;
  }
}

/**
 * Add product to cart and check stock
 */
async function addToCart(accessToken: string, storeCode: string, plu: string) {
  try {
    const body = createAddToCartBody(storeCode, plu);
    const headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0',
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.5',
      'Accept-Encoding': 'gzip, deflate, br, zstd',
      'Referer': 'https://www.klikindomaret.com/',
      'Content-Type': 'application/json',
      'Origin': 'https://www.klikindomaret.com',
      'Connection': 'keep-alive',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'no-cors',
      'Sec-Fetch-Site': 'same-site',
      'TE': 'trailers',
      'apps': '{"app_version":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0","device_class":"browser|browser","device_family":"none","device_id":"c03b3603-075e-4276-b420-a92d9ee93035","os_name":"Windows","os_version":"10"}',
      'Priority': 'u=4',
      'Pragma': 'no-cache',
      'Authorization': accessToken.trim(),
      'Cache-Control': 'no-cache',
    };

    const response = await axios.post(ADD_TO_CART_URL, body, { headers });
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(error.response?.data?.message || `Failed to add product ${plu} to cart: Network error`);
    }
    throw error;
  }
}

/**
 * Check stock by PLU
 */
export async function checkStockByPlu(accessToken: string, storeCode: string, plu: string): Promise<IndomaretProductStock> {
  try {
    // First reset the cart
    await resetCart(accessToken, storeCode);
    
    // Then add the product and check stock
    const result = await addToCart(accessToken, storeCode, plu);
    
    if (result.data && result.data.products && result.data.products.length > 0) {
      const product = result.data.products[0];
      return {
        productName: product.productName || 'Unknown Product',
        plu: product.plu || plu,
        stock: product.stock || 0,
        price: product.price || 'N/A',
        discountValue: product.discountValue,
        discountText: product.discountText,
      };
    } else {
      throw new Error(`No data returned for PLU ${plu}`);
    }
  } catch (error) {
    console.error(`Error checking stock for PLU ${plu} at store ${storeCode}:`, error);
    throw error;
  }
}
