import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Indomaret related schemas
export const stores = pgTable("stores", {
  id: serial("id").primaryKey(),
  storeCode: text("store_code").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertStoreSchema = createInsertSchema(stores).pick({
  storeCode: true,
  userId: true,
});

export type InsertStore = z.infer<typeof insertStoreSchema>;
export type Store = typeof stores.$inferSelect;

export const tokens = pgTable("tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTokenSchema = createInsertSchema(tokens).pick({
  userId: true,
  accessToken: true,
  refreshToken: true,
  expiresAt: true,
});

export type InsertToken = z.infer<typeof insertTokenSchema>;
export type Token = typeof tokens.$inferSelect;

export const stockChecks = pgTable("stock_checks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  plu: text("plu").notNull(),
  storeCode: text("store_code").notNull(),
  result: text("result").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertStockCheckSchema = createInsertSchema(stockChecks).pick({
  userId: true,
  plu: true,
  storeCode: true,
  result: true,
});

export type InsertStockCheck = z.infer<typeof insertStockCheckSchema>;
export type StockCheck = typeof stockChecks.$inferSelect;

// Zod schemas for API inputs
export const loginSchema = z.object({
  phoneNumber: z.string().min(10).max(15),
  password: z.string().min(6),
});

export const storeCodeSchema = z.object({
  storeCode: z.string().min(5),
});

export const checkStockSchema = z.object({
  pluList: z.array(z.string()),
  storeCodes: z.array(z.string()),
});

// Types for Indomaret API responses
export type IndomaretProductStock = {
  productName: string;
  plu: string;
  stock: number;
  price: string;
  discountValue?: string;
  discountText?: string;
};

export type IndomaretStore = {
  storeCode: string;
  storeName?: string;
};

export type IndomaretStockResult = {
  store: IndomaretStore;
  products: IndomaretProductStock[];
  error?: string;
};

export type IndomaretUserProfile = {
  name: string;
  phoneNumber: string;
};

export type IndomaretTokenInfo = {
  accessToken: string;
  refreshToken: string;
  expiresAt: Date;
};
