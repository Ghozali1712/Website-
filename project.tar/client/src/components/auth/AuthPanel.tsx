import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useAuth } from '../../contexts/AuthContext';
import { EyeIcon, EyeOffIcon, RefreshCwIcon, UserIcon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { getTimeToExpiry } from '../../lib/api';

export const AuthPanel: React.FC = () => {
  const { isLoggedIn, userProfile, tokenInfo, login, refreshToken, loading } = useAuth();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    await login(phoneNumber, password);
  };

  const handleRefreshToken = async () => {
    await refreshToken();
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-medium flex items-center">
          <span className="material-icons text-primary mr-2">account_circle</span>
          Authentication
        </CardTitle>
        <Badge variant={isLoggedIn ? "success" : "destructive"}>
          {isLoggedIn ? "Logged In" : "Logged Out"}
        </Badge>
      </CardHeader>
      <CardContent className="pt-6">
        {!isLoggedIn ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="material-icons text-muted-foreground text-sm">phone</span>
                </span>
                <Input 
                  id="phone"
                  type="tel"
                  placeholder="08xxxxxxxxxx"
                  className="pl-10"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="material-icons text-muted-foreground text-sm">lock</span>
                </span>
                <Input 
                  id="password"
                  type={showPassword ? "text" : "password"}
                  className="pl-10 pr-10"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute inset-y-0 right-0 px-3"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOffIcon className="h-4 w-4" /> : <EyeIcon className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full"
              disabled={loading}
            >
              {loading ? (
                <>
                  <RefreshCwIcon className="mr-2 h-4 w-4 animate-spin" />
                  Logging in...
                </>
              ) : (
                <>
                  <span className="material-icons mr-1 text-sm">login</span>
                  Login
                </>
              )}
            </Button>
          </form>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="bg-background rounded-full p-2">
                <UserIcon className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">{userProfile?.name}</h3>
                <p className="text-sm text-muted-foreground">{userProfile?.phoneNumber}</p>
              </div>
            </div>
            
            <div className="bg-muted rounded-md p-3 text-sm">
              <div className="flex justify-between mb-1">
                <span className="text-muted-foreground">Token Status:</span>
                <span className="text-green-500">Active</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Expires In:</span>
                <span>{tokenInfo ? getTimeToExpiry(new Date(tokenInfo.expiresAt)) : 'Unknown'}</span>
              </div>
            </div>
            
            <Button 
              variant="outline" 
              className="w-full"
              onClick={handleRefreshToken}
              disabled={loading}
            >
              {loading ? (
                <RefreshCwIcon className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCwIcon className="mr-2 h-4 w-4" />
              )}
              Refresh Token
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AuthPanel;
