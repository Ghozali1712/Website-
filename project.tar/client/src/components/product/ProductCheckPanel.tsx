import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useStores } from '../../contexts/StoreContext';
import { 
  ClockIcon, 
  SearchIcon, 
  RefreshCwIcon, 
  PackageIcon
} from 'lucide-react';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { checkStock } from '../../lib/api';
import { formatDate } from '../../lib/api';
import { useAuth } from '../../contexts/AuthContext';
import { IndomaretStockResult } from '../../types';

export const ProductCheckPanel: React.FC = () => {
  const { stores } = useStores();
  const { isLoggedIn } = useAuth();
  const [selectedStores, setSelectedStores] = useState<Record<string, boolean>>({});
  const [pluInput, setPluInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<IndomaretStockResult[]>([]);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);
  const [activeTab, setActiveTab] = useState('all');

  // Initialize selected stores when stores change
  React.useEffect(() => {
    const initialSelected: Record<string, boolean> = {};
    stores.forEach(store => {
      initialSelected[store.storeCode] = true;
    });
    setSelectedStores(initialSelected);
  }, [stores]);

  const handleCheckStock = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isLoggedIn) {
      return;
    }
    
    const pluList = pluInput.split(',').map(plu => plu.trim()).filter(Boolean);
    if (pluList.length === 0) return;
    
    const selectedStoreCodes = Object.entries(selectedStores)
      .filter(([_, isSelected]) => isSelected)
      .map(([storeCode]) => storeCode);
    
    if (selectedStoreCodes.length === 0) return;
    
    setLoading(true);
    
    try {
      const stockResults = await checkStock(pluList, selectedStoreCodes);
      setResults(stockResults);
      setLastChecked(new Date());
    } catch (error) {
      console.error("Error checking stock:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStockBadgeVariant = (stock: number) => {
    if (stock <= 0) return "destructive";
    if (stock < 10) return "warning";
    return "success";
  };

  const getStockLabel = (stock: number) => {
    if (stock <= 0) return "Out of Stock";
    if (stock < 10) return `${stock} Limited`;
    return `${stock} Available`;
  };

  // Filter results based on active tab
  const filteredResults = activeTab === 'all' 
    ? results 
    : results.filter(result => result.store.storeCode === activeTab);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-medium flex items-center">
          <span className="material-icons text-primary mr-2">inventory</span>
          Product Stock Checker
        </CardTitle>
        <Badge variant="outline" className="flex items-center">
          <ClockIcon className="h-3 w-3 mr-1" />
          Last Check: {formatDate(lastChecked)}
        </Badge>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="mb-6 bg-muted rounded-md p-4">
          <form onSubmit={handleCheckStock} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="plu-list">Product PLU Numbers</Label>
              <Textarea
                id="plu-list"
                placeholder="Enter PLU numbers separated by commas (e.g. 12345,67890)"
                value={pluInput}
                onChange={(e) => setPluInput(e.target.value)}
                className="min-h-[80px]"
                required
              />
              <p className="text-sm text-muted-foreground">
                Enter the PLU numbers for the products you want to check
              </p>
            </div>
            
            <div className="space-y-2">
              <Label>Select Stores to Check</Label>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {stores.map((store) => (
                  <label
                    key={store.storeCode}
                    className="flex items-center p-3 border rounded-md bg-card"
                  >
                    <Checkbox
                      checked={selectedStores[store.storeCode] || false}
                      onCheckedChange={(checked) => {
                        setSelectedStores(prev => ({
                          ...prev,
                          [store.storeCode]: !!checked
                        }));
                      }}
                      className="mr-2"
                    />
                    <span>Store #{store.storeCode}</span>
                  </label>
                ))}
              </div>
            </div>
            
            <div className="flex justify-end">
              <Button 
                type="submit" 
                disabled={loading || !isLoggedIn || stores.length === 0}
              >
                {loading ? (
                  <>
                    <RefreshCwIcon className="mr-2 h-4 w-4 animate-spin" />
                    Checking...
                  </>
                ) : (
                  <>
                    <SearchIcon className="mr-2 h-4 w-4" />
                    Check Stock
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
        
        {loading ? (
          <div className="flex justify-center items-center py-12">
            <RefreshCwIcon className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : (
          <div>
            {results.length > 0 ? (
              <>
                <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="mb-4">
                    <TabsTrigger value="all">
                      All Results ({results.reduce((acc, r) => acc + r.products.length, 0)})
                    </TabsTrigger>
                    {results.map(result => (
                      <TabsTrigger key={result.store.storeCode} value={result.store.storeCode}>
                        Store #{result.store.storeCode} ({result.products.length})
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  
                  <TabsContent value={activeTab} className="mt-0">
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Product</TableHead>
                            <TableHead>PLU</TableHead>
                            <TableHead>Store</TableHead>
                            <TableHead>Stock</TableHead>
                            <TableHead>Price</TableHead>
                            <TableHead>Discount</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredResults.flatMap(result => 
                            result.products.map(product => (
                              <TableRow key={`${result.store.storeCode}-${product.plu}`}>
                                <TableCell className="font-medium">{product.productName}</TableCell>
                                <TableCell>{product.plu}</TableCell>
                                <TableCell>{result.store.storeCode}</TableCell>
                                <TableCell>
                                  <Badge variant={getStockBadgeVariant(product.stock)}>
                                    {getStockLabel(product.stock)}
                                  </Badge>
                                </TableCell>
                                <TableCell>{product.price}</TableCell>
                                <TableCell>
                                  {product.discountValue ? (
                                    <div>
                                      <span className="text-red-500">{product.discountValue}</span>
                                      {product.discountText && (
                                        <div className="text-xs text-muted-foreground">{product.discountText}</div>
                                      )}
                                    </div>
                                  ) : (
                                    <span className="text-muted-foreground">-</span>
                                  )}
                                </TableCell>
                              </TableRow>
                            ))
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  </TabsContent>
                </Tabs>
              </>
            ) : (
              <div className="bg-muted rounded-md p-8 text-center">
                <PackageIcon className="h-12 w-12 mx-auto text-muted-foreground" />
                <p className="mt-2 text-muted-foreground">No stock information available</p>
                <p className="text-sm text-muted-foreground">Try checking different products or stores</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ProductCheckPanel;
