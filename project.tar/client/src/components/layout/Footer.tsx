import React from 'react';
import { Link } from "wouter";

export const Footer: React.FC = () => {
  return (
    <footer className="bg-background border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col sm:flex-row justify-between items-center">
          <div className="flex items-center mb-4 sm:mb-0">
            <span className="material-icons text-primary mr-2">storefront</span>
            <p className="text-sm text-muted-foreground">Indomaret Stock Checker Bot v2.0</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-muted-foreground hover:text-primary flex items-center cursor-pointer">
              <span className="material-icons text-sm mr-1">help_outline</span>
              Help
            </div>
            <div className="text-sm text-muted-foreground hover:text-primary flex items-center cursor-pointer">
              <span className="material-icons text-sm mr-1">description</span>
              Documentation
            </div>
            <div className="text-sm text-muted-foreground hover:text-primary flex items-center cursor-pointer">
              <span className="material-icons text-sm mr-1">code</span>
              API
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
