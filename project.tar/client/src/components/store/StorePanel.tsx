import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStores } from '../../contexts/StoreContext';
import { PlusIcon, EditIcon, TrashIcon, StoreIcon, XIcon } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export const StorePanel: React.FC = () => {
  const { stores, loading, addStore, deleteStore } = useStores();
  const [showAddForm, setShowAddForm] = useState(false);
  const [newStoreCode, setNewStoreCode] = useState('');
  const [storeToDelete, setStoreToDelete] = useState<string | null>(null);

  const handleAddStore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newStoreCode.trim()) {
      const success = await addStore(newStoreCode.trim());
      if (success) {
        setNewStoreCode('');
        setShowAddForm(false);
      }
    }
  };

  const handleDeleteStore = async () => {
    if (storeToDelete) {
      await deleteStore(storeToDelete);
      setStoreToDelete(null);
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-medium flex items-center">
          <span className="material-icons text-primary mr-2">store</span>
          Store Management
        </CardTitle>
        <Button size="sm" onClick={() => setShowAddForm(true)}>
          <PlusIcon className="h-4 w-4 mr-1" />
          Add Store
        </Button>
      </CardHeader>
      <CardContent className="pt-6">
        {stores.length > 0 ? (
          <div className="space-y-3">
            {stores.map((store) => (
              <div key={store.storeCode} className="bg-muted p-4 rounded-md">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-medium">Store #{store.storeCode}</h3>
                    {store.storeName && (
                      <p className="mt-1 text-sm text-muted-foreground">{store.storeName}</p>
                    )}
                  </div>
                  <div className="flex space-x-2">
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => setStoreToDelete(store.storeCode)}
                        >
                          <TrashIcon className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Store</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete Store #{store.storeCode}? This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel onClick={() => setStoreToDelete(null)}>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={handleDeleteStore}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-10 bg-muted rounded-md">
            <StoreIcon className="h-12 w-12 mx-auto text-muted-foreground" />
            <p className="mt-2 text-muted-foreground">No stores added yet</p>
            <Button 
              className="mt-4"
              size="sm"
              onClick={() => setShowAddForm(true)}
            >
              <PlusIcon className="h-4 w-4 mr-1" />
              Add Your First Store
            </Button>
          </div>
        )}

        <Dialog open={showAddForm} onOpenChange={setShowAddForm}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Store Code</DialogTitle>
              <DialogDescription>
                Enter the store code for the Indomaret location you want to check.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddStore}>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="store-code">Store Code</Label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="material-icons text-muted-foreground text-sm">numbers</span>
                    </span>
                    <Input
                      id="store-code"
                      placeholder="Enter store code (e.g. 12345)"
                      className="pl-10"
                      value={newStoreCode}
                      onChange={(e) => setNewStoreCode(e.target.value)}
                      required
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    You can add multiple codes separated by commas (e.g. 12345,67890)
                  </p>
                </div>
              </div>
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => {
                    setShowAddForm(false);
                    setNewStoreCode('');
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={loading}>
                  {loading ? 'Adding...' : 'Save Store'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default StorePanel;
