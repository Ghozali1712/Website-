import { apiRequest } from "./queryClient";
import { IndomaretStockResult } from "../types";

// Auth related API functions
export const login = async (phoneNumber: string, password: string) => {
  const response = await apiRequest('POST', '/api/auth/login', { phoneNumber, password });
  return response.json();
};

export const logout = async () => {
  const response = await apiRequest('POST', '/api/auth/logout');
  return response.json();
};

export const refreshToken = async () => {
  const response = await apiRequest('POST', '/api/auth/refresh-token');
  return response.json();
};

export const getUserProfile = async () => {
  const response = await apiRequest('GET', '/api/auth/profile');
  return response.json();
};

// Store related API functions
export const getStores = async () => {
  const response = await apiRequest('GET', '/api/stores');
  return response.json();
};

export const addStore = async (storeCode: string) => {
  const response = await apiRequest('POST', '/api/stores', { storeCode });
  return response.json();
};

export const deleteStore = async (storeCode: string) => {
  const response = await apiRequest('DELETE', `/api/stores/${storeCode}`);
  return response.json();
};

// Stock check related API functions
export const checkStock = async (pluList: string[], storeCodes: string[]): Promise<IndomaretStockResult[]> => {
  const response = await apiRequest('POST', '/api/stock/check', { pluList, storeCodes });
  return response.json();
};

export const getRecentChecks = async (limit = 10) => {
  const response = await apiRequest('GET', `/api/stock/recent?limit=${limit}`);
  return response.json();
};

// Date/time formatting helper
export const formatDate = (date: Date | null): string => {
  if (!date) return 'Never';
  
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  
  // Less than a minute
  if (diff < 60000) {
    return 'Just now';
  }
  
  // Less than an hour
  if (diff < 3600000) {
    const minutes = Math.floor(diff / 60000);
    return `${minutes} min${minutes !== 1 ? 's' : ''} ago`;
  }
  
  // Less than a day
  if (diff < 86400000) {
    const hours = Math.floor(diff / 3600000);
    return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
  }
  
  // Format as date
  return date.toLocaleString();
};

// Token expiry helper
export const getTimeToExpiry = (expiresAt: Date | null): string => {
  if (!expiresAt) return 'Expired';
  
  const now = new Date();
  const diff = expiresAt.getTime() - now.getTime();
  
  if (diff <= 0) {
    return 'Expired';
  }
  
  const minutes = Math.floor(diff / 60000);
  
  if (minutes < 60) {
    return `${minutes} minute${minutes !== 1 ? 's' : ''}`;
  }
  
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  
  return `${hours} hour${hours !== 1 ? 's' : ''} ${remainingMinutes} min${remainingMinutes !== 1 ? 's' : ''}`;
};
