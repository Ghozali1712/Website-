import {
  IndomaretProductStock,
  IndomaretStore,
  IndomaretStockResult,
  IndomaretUserProfile,
  IndomaretTokenInfo
} from "@shared/schema";

export type {
  IndomaretProductStock,
  IndomaretStore,
  IndomaretStockResult,
  IndomaretUserProfile,
  IndomaretTokenInfo
};

export type AuthState = {
  isLoggedIn: boolean;
  userProfile: IndomaretUserProfile | null;
  tokenInfo: IndomaretTokenInfo | null;
};

export type StoreState = {
  stores: IndomaretStore[];
  loading: boolean;
  error: string | null;
};

export type CheckResultState = {
  results: IndomaretStockResult[];
  loading: boolean;
  error: string | null;
  lastChecked: Date | null;
};
