import React, { useEffect } from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import AuthPanel from '@/components/auth/AuthPanel';
import StorePanel from '@/components/store/StorePanel';
import ProductCheckPanel from '@/components/product/ProductCheckPanel';
import { useAuth } from '../contexts/AuthContext';
import { useLocation } from 'wouter';

const Dashboard: React.FC = () => {
  const { isLoggedIn } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoggedIn) {
      setLocation("/login");
    }
  }, [isLoggedIn, setLocation]);

  if (!isLoggedIn) {
    return null; // The useEffect will redirect, return null to avoid rendering anything
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />
      
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="col-span-1 lg:col-span-1">
            <AuthPanel />
          </div>
          
          <div className="col-span-1 lg:col-span-2">
            <StorePanel />
          </div>
          
          <div className="col-span-1 lg:col-span-3">
            <ProductCheckPanel />
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Dashboard;
