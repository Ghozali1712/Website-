import React, { createContext, useContext, useState, useEffect } from "react";
import { StoreState, IndomaretStore } from "../types";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type StoreContextType = StoreState & {
  addStore: (storeCode: string) => Promise<boolean>;
  deleteStore: (storeCode: string) => Promise<boolean>;
  refreshStores: () => Promise<void>;
};

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<StoreState>({
    stores: [],
    loading: false,
    error: null
  });
  
  const { toast } = useToast();

  // Load stores when component mounts
  useEffect(() => {
    refreshStores();
  }, []);

  const refreshStores = async (): Promise<void> => {    
    setState(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const response = await apiRequest('GET', '/api/stores');
      const data = await response.json();
      
      setState({
        stores: data,
        loading: false,
        error: null
      });
    } catch (error) {
      console.error("Failed to fetch stores:", error);
      setState(prev => ({
        ...prev,
        loading: false,
        error: error instanceof Error ? error.message : "Failed to load stores"
      }));
      
      toast({
        title: "Failed to load stores",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    }
  };

  const addStore = async (storeCode: string): Promise<boolean> => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const response = await apiRequest('POST', '/api/stores', { storeCode });
      const newStore = await response.json();
      
      setState(prev => ({
        stores: [...prev.stores, newStore],
        loading: false,
        error: null
      }));
      
      toast({
        title: "Store added",
        description: `Store #${storeCode} has been added successfully`,
      });
      
      return true;
    } catch (error) {
      console.error("Failed to add store:", error);
      setState(prev => ({
        ...prev,
        loading: false,
        error: error instanceof Error ? error.message : "Failed to add store"
      }));
      
      toast({
        title: "Failed to add store",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
      
      return false;
    }
  };

  const deleteStore = async (storeCode: string): Promise<boolean> => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      await apiRequest('DELETE', `/api/stores/${storeCode}`);
      
      setState(prev => ({
        stores: prev.stores.filter(store => store.storeCode !== storeCode),
        loading: false,
        error: null
      }));
      
      toast({
        title: "Store deleted",
        description: `Store #${storeCode} has been removed`,
      });
      
      return true;
    } catch (error) {
      console.error("Failed to delete store:", error);
      setState(prev => ({
        ...prev,
        loading: false,
        error: error instanceof Error ? error.message : "Failed to delete store"
      }));
      
      toast({
        title: "Failed to delete store",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
      
      return false;
    }
  };

  return (
    <StoreContext.Provider value={{
      ...state,
      addStore,
      deleteStore,
      refreshStores
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStores = () => {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStores must be used within a StoreProvider');
  }
  return context;
};
