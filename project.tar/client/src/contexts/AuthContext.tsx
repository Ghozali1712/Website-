import React, { createContext, useContext, useState, useEffect } from "react";
import { AuthState, IndomaretUserProfile, IndomaretTokenInfo } from "../types";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";

type AuthContextType = AuthState & {
  login: (phoneNumber: string, password: string) => Promise<boolean>;
  logout: () => void;
  refreshToken: () => Promise<boolean>;
  loading: boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AuthState>({
    isLoggedIn: false,
    userProfile: null,
    tokenInfo: null
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [location, setLocation] = useLocation();

  // Check for existing session on mount
  useEffect(() => {
    const checkSession = async () => {
      try {
        const res = await fetch('/api/auth/session');
        if (res.ok) {
          const data = await res.json();
          setState({
            isLoggedIn: true,
            userProfile: data.userProfile,
            tokenInfo: data.tokenInfo
          });
        }
      } catch (error) {
        console.error("Failed to check session:", error);
      }
    };
    
    checkSession();
  }, []);

  // Check token expiry and refresh if needed
  useEffect(() => {
    if (state.isLoggedIn && state.tokenInfo) {
      // Instead of refreshing token automatically when close to expiry,
      // we'll only refresh when the user explicitly requests it or when
      // making API calls that need an active token.
      // This is because the Indomaret API seems to handle sessions differently,
      // and automatic refreshes might cause issues.
      
      // Just log the token expiry time for informational purposes
      const expiresAt = new Date(state.tokenInfo.expiresAt).getTime();
      const now = new Date().getTime();
      const timeUntilExpiry = Math.floor((expiresAt - now) / 1000 / 60); // minutes
      console.log(`Token expires in ${timeUntilExpiry} minutes`);
    }
  }, [state.isLoggedIn, state.tokenInfo]);

  const login = async (phoneNumber: string, password: string): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await apiRequest('POST', '/api/auth/login', { phoneNumber, password });
      const data = await response.json();
      
      setState({
        isLoggedIn: true,
        userProfile: data.userProfile,
        tokenInfo: data.tokenInfo
      });
      
      toast({
        title: "Login successful",
        description: `Welcome, ${data.userProfile.name}!`,
      });
      
      return true;
    } catch (error) {
      console.error("Login failed:", error);
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      await apiRequest('POST', '/api/auth/logout');
      setState({
        isLoggedIn: false,
        userProfile: null,
        tokenInfo: null
      });
      
      toast({
        title: "Logged out",
        description: "You have been successfully logged out",
      });
      
      setLocation('/login');
    } catch (error) {
      console.error("Logout failed:", error);
      toast({
        title: "Logout failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const refreshToken = async (): Promise<boolean> => {
    setLoading(true);
    try {
      console.log("Attempting to refresh token");
      
      // First check if we're actually logged in with a refresh token
      if (!state.isLoggedIn || !state.tokenInfo?.refreshToken) {
        console.error("Cannot refresh token: Not logged in or missing refresh token");
        throw new Error("Login session invalid");
      }
      
      const response = await apiRequest('POST', '/api/auth/refresh-token');
      
      // Check if the response is valid
      if (!response.ok) {
        const errText = await response.text();
        console.error("Token refresh failed with status:", response.status, errText);
        throw new Error(`Token refresh failed: ${response.status} ${errText}`);
      }
      
      const data = await response.json();
      
      if (!data.tokenInfo) {
        console.error("Token refresh response missing tokenInfo", data);
        throw new Error("Invalid token refresh response");
      }
      
      console.log("Token refreshed successfully");
      
      setState(prev => ({
        ...prev,
        tokenInfo: data.tokenInfo
      }));
      
      return true;
    } catch (error) {
      console.error("Token refresh failed:", error);
      
      // Display error toast
      toast({
        title: "Session error",
        description: error instanceof Error 
          ? error.message 
          : "Failed to refresh session token",
        variant: "destructive"
      });
      
      // If session is expired or invalid, force logout
      setState({
        isLoggedIn: false,
        userProfile: null,
        tokenInfo: null
      });
      
      // Redirect to login page
      setLocation('/login');
      
      return false;
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{
      ...state,
      login,
      logout,
      refreshToken,
      loading
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
