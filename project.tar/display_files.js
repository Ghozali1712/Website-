import { readFileSync } from 'fs';
import { dirname } from 'path';
import { fileURLToPath } from 'url';

// Daftar file yang akan ditampilkan
const filesToShow = [
  // File konfigurasi
  'package.json',
  'tsconfig.json',
  'vite.config.ts',
  'tailwind.config.ts',
  'postcss.config.js',
  'drizzle.config.ts',
  
  // Client files
  'client/index.html',
  'client/src/App.tsx',
  'client/src/main.tsx',
  'client/src/index.css',
  
  // Server files
  'server/index.ts',
  'server/routes.ts',
  'server/storage.ts',
  'server/vite.ts',
  
  // Shared files
  'shared/schema.ts',
  
  // Core component files
  'client/src/components/auth/AuthPanel.tsx',
  'client/src/components/layout/Header.tsx',
  'client/src/components/layout/Footer.tsx',
  'client/src/components/product/ProductCheckPanel.tsx',
  'client/src/components/store/StorePanel.tsx',
  
  // Context files
  'client/src/contexts/AuthContext.tsx',
  'client/src/contexts/StoreContext.tsx',
  
  // Lib files
  'client/src/lib/api.ts',
  'client/src/lib/queryClient.ts',
  'client/src/lib/utils.ts',
  
  // Pages
  'client/src/pages/Dashboard.tsx',
  'client/src/pages/Login.tsx',
  'client/src/pages/not-found.tsx',
  
  // Hook files
  'client/src/hooks/use-mobile.tsx',
  'client/src/hooks/use-toast.ts',
  
  // Type files
  'client/src/types/index.ts',
  
  // Server services
  'server/services/indomaretApi.ts',
  'server/services/telegramBot.ts',
  
  // Asset files
  'attached_assets/addBody.js',
  'attached_assets/addToCart.js',
  'attached_assets/getProfile.js',
  'attached_assets/main.js',
  'attached_assets/resetBody.js',
  'attached_assets/resetCart.js',
  'attached_assets/tutorial.html'
];

// Fungsi untuk menampilkan konten file
async function displayFileContent(filePath) {
  try {
    const content = readFileSync(filePath, 'utf8');
    console.log(`\n\n=============================================`);
    console.log(`FILE: ${filePath}`);
    console.log(`=============================================`);
    console.log(content);
    console.log(`\n\n`);
  } catch (error) {
    console.log(`\n\n=============================================`);
    console.log(`ERROR: Tidak dapat membaca file ${filePath}`);
    console.log(`Error: ${error.message}`);
    console.log(`=============================================\n\n`);
  }
}

// Fungsi utama
async function main() {
  console.log('DAFTAR KONTEN FILE PROYEK\n');
  console.log('Salin dan buat ulang setiap file di komputer lokal Anda\n');
  
  for (const file of filesToShow) {
    await displayFileContent(file);
  }
  
  console.log('SELESAI: Semua file telah ditampilkan');
}

// Jalankan program
main().catch(error => {
  console.error('Terjadi kesalahan:', error);
});